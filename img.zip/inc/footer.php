 

	<div class="footer-bottom-data">
		<div class="container">

			<ul class="footer-info">
				<li class="footer-copyright">
					&#169; Vikash
				</li>

				<li class="footer-links">

					<ul id="footer-nav" class="footer-nav" style="display: none;">
						<li id="menu-item-296" class="menu-item menu-item-type-taxonomy menu-item-object-category current-post-ancestor current-menu-parent current-post-parent menu-item-296">
							<a href="#">About</a>
						</li>
						<li id="menu-item-297" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-297">
							<a href="#">Privacy</a>
						</li>
						<li id="menu-item-298" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-298">
							<a href="#">Desclaimer</a>
						</li>
					</ul>
				</li>
			</ul>

		</div><!-- .container -->
	</div>
	<a href="" class="goto-top backtotop"><i class="icon-up-open"></i></a>
 