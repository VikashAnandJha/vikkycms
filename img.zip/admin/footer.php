<footer class="main-footer">
    <div class="pull-right hidden-xs">Version 1.0</div>
    Copyright © 2020 vikkyCMS. All rights reserved.</footer>