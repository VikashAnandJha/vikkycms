# To WordPress and its shittier load time
An Open Source CMS for building websites and blogs 
help is aprreciated in anyway